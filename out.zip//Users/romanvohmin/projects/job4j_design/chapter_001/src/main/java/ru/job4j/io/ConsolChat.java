package ru.job4j.io;

import java.util.Comparator;
import java.util.Objects;
import java.util.Scanner;
import java.util.zip.ZipOutputStream;

/**
 * ru.job4j.io.consolChat
 *
 * @author romanvohmin
 * @version 1
 * @since 23.03.2020
 */
public class ConsolChat {
    Scanner scanner = new Scanner(System.in);
    String word = scanner.nextLine();
}