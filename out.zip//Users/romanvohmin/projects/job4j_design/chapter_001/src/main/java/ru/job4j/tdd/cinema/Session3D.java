package ru.job4j.tdd.cinema;

import java.util.List;

/**
 * @author RVohmin
 * @since 15.03.2020
 */
public class Session3D implements Session {
}
