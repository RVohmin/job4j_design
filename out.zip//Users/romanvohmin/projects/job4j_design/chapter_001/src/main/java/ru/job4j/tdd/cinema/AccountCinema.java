package ru.job4j.tdd.cinema;

/**
 * @author RVohmin
 * @since 15.03.2020
 */
public class AccountCinema implements Account {
}
