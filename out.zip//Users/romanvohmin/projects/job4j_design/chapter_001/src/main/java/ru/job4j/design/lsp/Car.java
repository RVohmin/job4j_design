package ru.job4j.design.lsp;

/**
 * @author RVohmin
 * @since 18.03.2020
 */
public interface Car {
    int size();
    int number();
}
